import os

BASE_URL = os.getenv(
    "GEO_INFERENCE_BASE_URL",
    "https://geo-model-gateway-api-nasageospatial-"
    "dev.cash.sl.cloud9.ibm.com/v2/inference/",
)
INFERENCE_URL = (
    "https://geo-model-gateway-api-nasageospatial-" "dev.cash.sl.cloud9.ibm.com"
)
GEOSERVER_URL = (
    "https://gfm-geoserver-nasageospatial-dev.cash.sl.cloud9.ibm.com/geoserver"
    # "https://geostudio-ui-nasageospatial-dev.cash.sl.cloud9.ibm.com/geofm-geoserver/geoserver/geofm/wms/"
    
)
